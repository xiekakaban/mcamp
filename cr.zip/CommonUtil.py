﻿import urllib
import urllib.request

enable_proxy = True
def getContentFromPath(url,data={},header={}):
	proxy_handler = urllib.request.ProxyHandler({"http" : 'http://proxy.statestr.com/'})
	null_proxy_handler = urllib.request.ProxyHandler({})
	if enable_proxy:
		opener = urllib.request.build_opener(proxy_handler)
	else:
		opener = urllib.request.build_opener(null_proxy_handler)
	urllib.request.install_opener(opener)
	try:
		request = urllib.request.Request(url);
		response = urllib.request.urlopen(request)
	except urllib.error.URLError as e:
		if hasattr(e,'code'):
			print(e.code)
		if hasattr(e,'reason'):
			print(e.reason)
	else:
		return response.read();