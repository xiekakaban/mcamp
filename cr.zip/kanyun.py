﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-

class KanYun:
	#__imageName
	#__title
	#__view

	def __init__(self,imageName,title,view):
		self.__imageName = imageName
		self.__title = title
		self.__view = view
		
	def get_imageName(self):
		return self.__imageName
	def set_imageName(self,imageName):
		self.__imageName = imageName
	
	def get_title(self):
		return self.__title
	def set_title(self,title):
		self.__title = title
		
	def get_view(self):
		return self.__view
	def set_view(self,view):
		self.__view = view
		
	def __repr__(self):
		return self.__imageName+","+self.__title+","+self.__view
	
		