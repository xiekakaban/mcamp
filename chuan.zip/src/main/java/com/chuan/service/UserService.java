package com.chuan.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.chuan.dao.UserDao;
import com.chuan.entity.UserEntity;

public interface UserService{
	/**验证用户登陆*/
	UserEntity checkUser(String userName,String pwd);
}
