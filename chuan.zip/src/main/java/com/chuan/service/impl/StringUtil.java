package com.chuan.service.impl;

public class StringUtil {
	public static boolean notNullorEmpty(String str){
		if(str == null || str == "" || str.length() == 0){
			return false;
		}
		return true;
	}
}
