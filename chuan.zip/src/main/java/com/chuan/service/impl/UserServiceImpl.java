package com.chuan.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.chuan.dao.UserDao;
import com.chuan.entity.UserEntity;
import com.chuan.service.UserService;
import com.chuan.util.SecurityUtil;

@Service("userService")
public class UserServiceImpl implements UserService{
	@Autowired
	@Qualifier("userDao")
	private UserDao userDao;

	@Override
	public UserEntity checkUser(String userName, String pwd) {
		return userDao.getUser(userName, SecurityUtil.convertMD5(pwd));
	}
	
}
