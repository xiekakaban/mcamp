package com.chuan.util;

public class Constant {
	/**Session*/
	public static final String SESS_USER = "user";
	
	
	/**View*/
	public static final String VEW_FLASH = "flash";
}
