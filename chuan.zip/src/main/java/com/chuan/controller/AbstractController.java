package com.chuan.controller;

public abstract class AbstractController {

	public static void sysout(String msg){
		System.out.println(msg);;
	}
}
