package com.chuan.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.chuan.entity.UserEntity;
import com.chuan.service.UserService;
import com.chuan.util.Constant;
import com.chuan.util.SecurityUtil;

@Controller
@RequestMapping(value="/user") 
public class UserController extends AbstractController{
	@Autowired
	@Qualifier("userService")
	private UserService userService;
	
	Logger logger = Logger.getLogger(UserController.class);
	@RequestMapping(value="/login",method={RequestMethod.POST})
	public String userLogin(UserEntity user,HttpServletRequest request,RedirectAttributes redirAttr){
		if(user.getUserName()!=null && user.getPwd()!=null){
			UserEntity loginEntity = userService.checkUser(user.getUserName(),user.getPwd());
			if(loginEntity!=null){
				request.getSession().setAttribute(Constant.SESS_USER,loginEntity);
				redirAttr.addFlashAttribute(Constant.VEW_FLASH,"Login Success");
			}
			else{
				redirAttr.addFlashAttribute(Constant.VEW_FLASH,"Please check Your UserName/Password");
			}
		}
		return "redirect:/";
	}
}
	
