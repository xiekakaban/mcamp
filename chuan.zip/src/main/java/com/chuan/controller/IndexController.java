package com.chuan.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.chuan.service.impl.StringUtil;
import com.chuan.util.Constant;

@Controller
public class IndexController {
	@RequestMapping(value="/",method=RequestMethod.GET)
	public ModelAndView index(RedirectAttributes redirAttr){
		ModelAndView modelAndView = new ModelAndView();
		String flashStr = String.valueOf(redirAttr.getFlashAttributes().get(Constant.VEW_FLASH));
		if(StringUtil.notNullorEmpty(flashStr)){
			modelAndView.addObject(Constant.VEW_FLASH,flashStr);
		}
		modelAndView.setViewName("index");
		return modelAndView;
	}
}
