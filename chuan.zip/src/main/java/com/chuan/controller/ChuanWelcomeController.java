package com.chuan.controller;


import java.util.List;


import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.chuan.entity.UserEntity;

@Controller
@RequestMapping(value="/")
public class ChuanWelcomeController {
	
	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	@RequestMapping(value="welcome",method={RequestMethod.POST,RequestMethod.GET})
	public String welcome(ModelMap model){
		StringBuffer sb = new StringBuffer();
		Session hiSession = sessionFactory.openSession();
		Transaction transaction = hiSession.beginTransaction();
		Query query = hiSession.createQuery("select u FROM UserEntity u");
		List<UserEntity> users = query.list();
		for(UserEntity user : users){
			sb.append(user.getUserName()).append(" with password:").append(user.getPwd()).append("<br/>");
		}
		transaction.commit();
		hiSession.close();
		model.addAttribute("message",sb.toString());
		return "common/welcome";
	}
	
}
