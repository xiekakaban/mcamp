package com.chuan.entity;

public abstract class AbstractEntity {

}
