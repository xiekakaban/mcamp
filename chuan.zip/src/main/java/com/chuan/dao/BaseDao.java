package com.chuan.dao;

import java.io.Serializable;
import java.util.List;

public interface BaseDao<T> {
	/**根据ID获取实体类*/
	T get(Class<T> entityClazz,Serializable id);
	/**保存*/
	Serializable save(T entity);
	/**更新*/
	void update(T entity);
	/**删除*/
	void delete(T entity);
	/**根据Id删除实体*/
	void deleteById(Class<T> entityClazz,Serializable id);
	/**获取所有实体*/
	List<T> findAll(Class<T> entityClazz);
	/**获取实体总数*/
	long count(Class<T> entityClazz);
}
