package com.chuan.dao.impl;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.transaction.annotation.Transactional;

import com.chuan.dao.BaseDao;

@Transactional
public class BaseDaoImpl<T> implements BaseDao<T> {

	@Autowired
	@Qualifier("sessionFactory")
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	@Override
	public T get(Class<T> entityClazz, Serializable id) {
		return (T) sessionFactory.getCurrentSession().get(entityClazz, id);
	}

	@Override
	public Serializable save(T entity) {
		return sessionFactory.getCurrentSession().save(entity);
	}

	@Override
	public void update(T entity) {
		sessionFactory.getCurrentSession().saveOrUpdate(entity);
	}

	@Override
	public void delete(T entity) {
		sessionFactory.getCurrentSession().delete(entity);
	}

	@Override
	public void deleteById(Class<T> entityClazz, Serializable id) {
		sessionFactory.getCurrentSession().createQuery("delete " + entityClazz.getSimpleName() + " entity where entity.id = ?0").setParameter("0", id);

	}

	@Override
	public List<T> findAll(Class<T> entityClazz) {
		return (List<T>) (sessionFactory.getCurrentSession().createQuery("select * from " + entityClazz.getSimpleName() + " entity").list());
	}

	@Override
	public long count(Class<T> entityClazz) {
		// TODO Auto-generated method stub
		List<T> result = sessionFactory.getCurrentSession().createQuery("select count(*) from " + entityClazz.getSimpleName() +" entity").list();
		if(result != null && result.get(0)!=null){
			return (Long)(result.get(0));
		}
		return 0;
	}
	protected Query executeHQL(String hql){
		return sessionFactory.getCurrentSession().createQuery(hql);
	}
	protected Query executeHQL(String hql,Object... params){
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		for(int i=0; i<params.length; i++){
			query.setParameter(i+"", params[i]);
		}
		return query;
	}

}
