package com.statestr.cp.common.util;

public class StringUtil {
	
	public static boolean nullOrEmpty(String str){
		if(str==null || str.length()==0){
			return true;
		}
		else{
			return false;
		}
	}
}
