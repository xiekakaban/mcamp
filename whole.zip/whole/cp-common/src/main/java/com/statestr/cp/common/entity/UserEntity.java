package com.statestr.cp.common.entity;

import java.io.Serializable;

public class UserEntity implements Serializable{
	
	private static final long serialVersionUID = -6750142172615014714L;
	private String id;
	private String username;
	private String pwd;
	//private String avator;
	//private String emial;
	//private String weichat;
	//private String location;
	//private Date birthday;
	//private Date last_login_time;
	//private Date create_time;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
}
