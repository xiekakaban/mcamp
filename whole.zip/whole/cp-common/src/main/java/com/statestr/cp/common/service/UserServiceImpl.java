package com.statestr.cp.common.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.statestr.cp.common.dao.UserDao;
import com.statestr.cp.common.entity.UserEntity;
import com.statestr.cp.common.util.SecurityUtil;

@Service("userService")
public class UserServiceImpl implements UserService{
	@Autowired
	@Qualifier("userDao")
	private UserDao userDao;

	public UserEntity checkUser(String userName, String pwd) {
		return userDao.getUser(userName, SecurityUtil.convertMD5(pwd));
	}
	
}
