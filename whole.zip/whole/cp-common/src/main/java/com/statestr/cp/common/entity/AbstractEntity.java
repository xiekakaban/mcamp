package com.statestr.cp.common.entity;

public class AbstractEntity {

}
