package com.statestr.cp.common.dao;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.statestr.cp.common.entity.UserEntity;

@Repository("userDao")
@Transactional
public class UserDaoImpl extends BaseDaoImpl<UserEntity> implements UserDao{

	@Transactional
	public UserEntity getUser(String userName, String pwd) {
		Query query = executeHQL("select userEntity from UserEntity userEntity where userName=?0 and pwd=?1" ,userName,pwd);
		return (UserEntity)query.uniqueResult();
	}

	
}
