package com.statestr.cp.common.dao;

import com.statestr.cp.common.entity.UserEntity;

public interface UserDao extends BaseDao<UserEntity>{
	/**通过userName和Pwd获取User*/
	UserEntity getUser(String userName,String pwd);
}
