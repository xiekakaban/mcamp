package com.statestr.cp.common.service;

import com.statestr.cp.common.entity.UserEntity;

public interface UserService{
	/**验证用户登陆*/
	UserEntity checkUser(String userName,String pwd);
}
